#include<iostream>
#include<string>
#include<vector>
#include<cmath>
#include<fstream>
using namespace std;
class Student {
public:
    string name;
    string numberPhone;
    float grade;

public:

    void getInfo(fstream& myStudent) {

         getline(myStudent,name);
         getline(myStudent,numberPhone);
         string buffer;
         getline(myStudent,buffer);
         grade=toFloat(buffer);
    }

    void display() {
        cout << "Student's information:" << endl;
        cout << "Name: " << name << endl;
        cout << "Grade: " <<grade << endl;
        cout << "Number Phone: " <<numberPhone << endl;
    }

private:

    float toFloat(string buffer){
        float res=0;
        int n=buffer.size();
        int exponent=0;
        for(int i=0;i<n;i++){
            float ppow=pow(10,exponent);
            if(buffer[i]!='.'){
                res+=(buffer[i]-'0')/ppow;
                exponent++;
            }
        }

        return res;
    }


};
