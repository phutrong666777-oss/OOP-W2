#include "student.h"
#include <algorithm>

class ClassRoom{
    vector <Student> studentList;

public:

    void addStudent(Student students);

    void removeStudent(string nameStudent);

    void sortStudentGrade();

    void printStudentList();

private:

    bool isAddedStudent(Student student);

    int getStudentIndex(string name);

};